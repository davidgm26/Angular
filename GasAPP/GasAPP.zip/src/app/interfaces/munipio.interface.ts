export interface MunicipioResponse {
    IDMunicipio: string;
    IDProvincia: string;
    IDCCAA:      string;
    Municipio:   string;
}

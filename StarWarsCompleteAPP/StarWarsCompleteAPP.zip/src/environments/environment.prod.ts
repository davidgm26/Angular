export const environment = {
  production: true,
  apiBaseUrl: 'https://swapi.dev/api/'
};
